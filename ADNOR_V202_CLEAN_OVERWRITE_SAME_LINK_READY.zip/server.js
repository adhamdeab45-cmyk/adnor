const http = require('http');
const fs = require('fs');
const path = require('path');
const root = __dirname;
const types = {'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml'};
function send(res, code, body, type='text/plain; charset=utf-8'){ res.writeHead(code, {'Content-Type': type, 'Cache-Control':'no-store'}); res.end(body); }
http.createServer((req,res)=>{
  let u = decodeURIComponent((req.url||'/').split('?')[0]);
  if (u === '/') u = '/index.html';
  let file = path.normalize(path.join(root, u));
  if (!file.startsWith(root)) return send(res,403,'Forbidden');
  fs.stat(file,(err,st)=>{
    if(err || !st.isFile()) file = path.join(root,'index.html');
    fs.readFile(file,(e,b)=> e ? send(res,500,String(e)) : send(res,200,b,types[path.extname(file)]||'application/octet-stream'));
  });
}).listen(process.env.PORT || 3000, ()=> console.log('ADNOR V202 clean server running'));
