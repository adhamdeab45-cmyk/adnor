(function(){
  try { console.warn('ADNOR V202: legacy script disabled. Loading clean version.'); } catch(e) {}
  try { window.ADNOR_VERSION = 'V202_CLEAN_OVERWRITE'; } catch(e) {}
  try { localStorage.setItem('ADNOR_FORCE_VERSION','V202_CLEAN_OVERWRITE'); } catch(e) {}
  var clean = '/index.html?v=202-clean-overwrite-' + Date.now();
  try {
    // If an old cached page loaded this legacy file, force a fresh clean page.
    if (!location.search.includes('v=202-clean-overwrite')) setTimeout(function(){ location.replace(clean); }, 50);
  } catch(e) {}
})();
